import java.util.ArrayList;

/* 
  creates array and initalizes enemies. after enemies are created, they are added to the array
  Dillon, Bruce, Lukas
  ICS4U1
  Jan 26 2021
*/
class Enemy {
  public ArrayList<Character> getEnemy() {
    ArrayList<Character> enemies = new ArrayList<Character>();
    // get stat values for minion1 on floor 1
    Character minion1 = new Character(100, 60, 40, 80, "Arachnid", 0, 0, 0);
    enemies.add(minion1);
    // get stat values for minion2 on floor 1
    Character minion2 = new Character(120, 65, 20, 80, "Demon Sorcerous", 0, 0, 0);
    enemies.add(minion2);
    // get stat values for minion3 on floor 1
    Character minion3 = new Character(130, 62, 60, 80, "Ape", 0, 0, 0);
    enemies.add(minion3);
    // get stat values for boss1 on floor 1
    Character boss1 = new Character(140, 70, 60, 80, "Winged Lion", 0, 0, 0);
    enemies.add(boss1);
    // get stat values for minion4 on floor 2
    Character minion4 = new Character(140, 70, 50, 80, "Bat", 0, 0, 0);
    enemies.add(minion4);
    // get stat values for minion5 on floor 2
    Character minion5 = new Character(140, 70, 50, 80, "Eagle", 0, 0, 0);
    enemies.add(minion5);
    // get stat values for minion6 on floor 2
    Character minion6 = new Character(140, 70, 50, 80, "Black Mamba", 0, 0, 0);
    enemies.add(minion6);
    // get stat values for boss2 on floor 2
    Character boss2 = new Character(150, 80, 70, 80, "Ogre", 0, 0, 0);
    enemies.add(boss2);
    // get stat values for minion7 on floor 3
    Character minion7 = new Character(150, 78, 70, 120, "Tiger King", 0, 0, 0);
    enemies.add(minion7);
    // get stat values for minion8 on floor 3
    Character minion8 = new Character(150, 78, 70, 80, "Elephant", 0, 0, 0);
    enemies.add(minion8);
    // get stat values for minion9 on floor 3
    Character minion9 = new Character(150, 80, 70, 90, "Scorpion King", 0, 0, 0);
    enemies.add(minion9);
    // get stat values for boss3 on floor 3
    Character boss3 = new Character(170, 90, 80, 90, "Hell Hound", 0, 0, 0);
    enemies.add(boss3);
    // get stat values for THE FINAL BOSS
    Character bossF = new Character(200, 95, 80, 90, "Diabolos", 0, 0, 0);
    enemies.add(bossF);
    // gets stats for ultimate final boss
    Character bossUf = new Character(200, 100, 60, 90, "Diabolos", 0, 0, 0);
    enemies.add(bossUf);
    return enemies;
  }
}