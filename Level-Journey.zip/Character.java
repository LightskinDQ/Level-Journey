/*
  This class is used for pretty much all actions in the game and for getting the stat values for each character.
  Dillon, Bruce, Lukas
  ICS4U1
  Jan 26 2021
*/

class Character {

  // set variables
  int h;
  int a;
  int d;
  int s;
  String t;
  int exp;
  int bar;
  int l;

  /*
    constructor used to create objects (health, attack, defense, speed, type ,exp, exp bar) 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public Character(int health, int attack, int defence, int speed, String type, int experience, int experienceBar,
      int level) {
    this.h = health;
    this.a = attack;
    this.d = defence;
    this.s = speed;
    this.t = type;
    this.exp = experience;
    this.bar = experienceBar;
    this.l = level;
  }

  /*
    gets function for health 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int getH() {
    return h;
  }

  /*
    gets function for attack 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int getA() {
    return a;
  }

  /*
    gets function for defense 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int getD() {
    return d;
  }

  /*
    gets function for speed 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int getS() {
    return s;
  }

  /*
    gets function for type of character 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public String getT() {
    return t;
  }

  /*
    adds one experience point to the characters exp 
    Dillon, Bruce, Lukas 
    ICS4U1
    Jan 26 2021
  */
  public int addExperience() {
    exp += 1;
    return exp;
  }

  /*
   gets function for exp 
   Dillon, Bruce, Lukas 
   ICS4U1 
   Jan 26 2021
  */
  public int getExperience() {
    return exp;
  }

  /*
    gets function for exp bar 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int getBar() {
    return bar;
  }

  /*
    gets function to get level 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int getL() {
    return l;
  }

  /*
    function for character to level up 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void levelUp() {
    System.out.println();
    exp = 0;
    if (t.equals("Attack") || t.equals("Speed")) {
      h += 2;
      a += 3;
      d += 3;
      s += 2;

    } else {
      h += 2;
      a += 2;
      d += 4;
      s += 3;
    }
    l++;
  }

  /*
    Shows stats for character 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void showStats() {
    String type = getT();
    System.out.println(type + " Character");
    System.out.println("Health: " + getH());
    System.out.println("Attack: " + getA());
    System.out.println("Defense: " + getD());
    System.out.println("Speed: " + getS());
  }// show stats

  /*
    Checks to see if the user leveled up 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void checkLevelUp() {
    if (exp == bar) {
      levelUp();
      System.out.println("You leveled up. Your now at level: " + l);
      System.out.println("Here are your stats");
      showStats();
    } // if statement to check if they leveled up
  }// check level up

}