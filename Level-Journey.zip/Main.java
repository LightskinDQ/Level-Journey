/* 
  Level Journey
  Dillon, Bruce, Lukas
  ICS4U1
  Jan 26 2021
*/
class Main {
  /*
    Main Method Sends to Main Display 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public static void main(String[] args) {
    Welcome game = new Welcome();
    game.welcome();
  }
}