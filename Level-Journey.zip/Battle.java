import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/* 
  Battle function calling the character the user creates into the class
  Dillon, Bruce, Lukas
  ICS4U1
  Jan 26 2021
*/
class Battle {
  Character user;
  public static int floor = 0;// creates floor variable to indicate later which floor your on
  public static int total = 0;
  public static int total1 = 0;
  // Declaring ANSI_RESET so that we can reset the color
  public static final String ANSI_RESET = "\u001B[0m";
  // Declaring the color
  // Custom declaration
  public static final String ANSI_YELLOW = "\u001B[33m";
  public static final String ANSI_RED = "\u001B[31m";
  public static final String ANSI_GREEN = "\u001B[32m";
  public static final String ANSI_BLUE = "\u001B[34m";
  public static final String ANSI_PURPLE = "\u001B[35m";

  /*
    Initializing user 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public Battle(Character attack) {
    this.user = attack;
  }

  /*
    Fight between the user and enemy 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void start() {
    Scanner in = new Scanner(System.in);
    boolean win = false;
    boolean dodge = false;
    int move = 0;
    boolean cont = false;

    int attackBoostCounter = 0;// creates attack booster tracker variable
    int damageCounter = 0;// creates damage tracker variable
    int attackDefenseReduction = 0;

    Enemy enemy = new Enemy();
    ArrayList<Character> enemies = enemy.getEnemy();

    Character f1 = enemies.get(floor);// traverses array to get specific character depending on the floor your on
    System.out.println("");
    System.out.println(ANSI_RED + "You are fighting a " + f1.t + ANSI_RESET);
    System.out.println("");
    System.out.println(ANSI_GREEN + f1.t + " has " + f1.h + " health" + ANSI_RESET);
    System.out.println("");
    System.out.println(ANSI_BLUE + f1.t + " has " + f1.d + " defense." + ANSI_RESET);
    System.out.println();
    time();

    while (win == false) {
      while (move != 1 || move != 2) {// while loop to make sure user enters 1 or 2
        while (cont == false) { // error proof to make sure the user can only enter a int number
          try {
            System.out.println("Choose what do you want to do. Type 1 or 2.");
            System.out.println(ANSI_RED + "1. Attack: Deal Base Damage of " + user.a);
            System.out.println(ANSI_RED + "2. Sword's Dance: Increase your Attack Stat by 50" + ANSI_RESET);
            System.out.println("");
            move = in.nextInt();// user inputs attack
            System.out.println("");
            cont = true;
          } catch (Exception e) {// checks to see if user put right letter
            System.out.println(ANSI_YELLOW + "Invalid Input. Try again." + ANSI_RESET);
            cont = false;
          }
          in.nextLine();
        } // while loop to check if user enters correct input: integer
        cont = false;
        if (move == 1 || move == 2) {// breaks out of the loop when the user puts in 1 or 2
          break;
        } else {// checks to see if user put in right number
          System.out.println(ANSI_YELLOW + "Invalid Input. Try again" + ANSI_RESET);
        }
      }

      if (user.s >= f1.s) { // checks to see which speed is faster
        System.out.println(ANSI_PURPLE + "You are faster than " + f1.t + ANSI_RESET);
        System.out.println("");

        if (move == 1) {
          boolean dodge1 = checkIfDodge(dodge); // goes to dodge method to see if the user or the fighter dodges the attack
          dodge = dodge1; // sets dodge to either true or false
          if (dodge == true) {// if dodge is true then it goes to the next turn
            System.out.println("The " + f1.t + " dodged the attack");
            System.out.println("");
            time();
          } else {// if the user or the fighter doesnt dodge then it will attack normally
            int uA = userAttack(f1);
          } // 1st else
          if (f1.h < 0) {// checks to see if health is less than 0 so when the health of either the user or the fighter is less then 0, it auto changes to 0 because you cant have negitive health
            f1.h = 0;
          }
          if (dodge == false) {
            attackDefenseReduction = user.a - f1.d;// tracker to see how much damage is being done after defense reduction and if the number is a negitive number, it reverts up to 0
            if (attackDefenseReduction < 0) {
              attackDefenseReduction = 0;
            }
            System.out.println("You attacked. You did " + attackDefenseReduction + " damage. " + ANSI_GREEN + f1.t
                + " is now at " + f1.h + " health" + ANSI_RESET);
            System.out.println("");
            time();
            attackDefenseReduction = 0;
          }
          if (f1.h <= 0 || user.h <= 0) { // checks to see if either the fighter or the user is at 0 health so once one player is, it will break out of the loop
            win = true;
            break;
          }
        }
        if (move == 2) {
          user.a = user.a + 50; // increases attack by 50 points
          attackBoostCounter++;
          System.out.println(
              ANSI_RED + "You did an attack boost. Your attack stat is now at " + user.a + " points" + ANSI_RESET);
          System.out.println("");
          time();
        }
        boolean dodge2 = checkIfDodge(dodge);// goes to dodge method to see if the user or the fighter dodges the attack
        dodge = dodge2;// sets dodge to either true or false
        if (dodge == true) {// if dodge is true then it goes to the next turn
          System.out.println("You dodged the attack");
          System.out.println("");
          time();
        } else {// if the user or the fighter doesnt dodge then it will attack normally
          int fA = fighterAttack(f1);
        } // 1st else
        if (user.h < 0) {// checks to see if health is less than 0 so when the health of either the user or the fighter is less then 0, it auto changes to 0 because you cant have negitive health
          user.h = 0;
        }
        if (dodge == false) {
          attackDefenseReduction = f1.a - user.d;// tracker to see how much damage is being done after defense reduction and if the number is a negitive number, it reverts up to 0
          if (attackDefenseReduction < 0) {
            attackDefenseReduction = 0;
          }
          System.out.println(f1.t + " attacked. " + f1.t + " did " + attackDefenseReduction + " damage." + ANSI_GREEN + " You are now at " + user.h + " health" + ANSI_RESET);
          System.out.println("");
          time();
          attackDefenseReduction = 0;
          damageCounter++;
        }
        if (f1.h <= 0 || user.h <= 0) {// checks to see if either the fighter or the user is at 0 health so once one player is, it will break out of the loop
          win = true;
          break;
        }
      }
      // else statement for if the users speed is slower than the enemys speed
      else {
        System.out.println(ANSI_PURPLE + "You are slower than " + f1.t + ANSI_RESET);
        System.out.println("");
        boolean dodge3 = checkIfDodge(dodge);// goes to dodge method to see if the user or the fighter dodges the attack
        dodge = dodge3;// sets dodge to either true or false
        if (dodge == true) {// if dodge is true then it goes to the next turn
          System.out.println("You dodged the attack");
          System.out.println("");
          time();
        } else {// if the user or the fighter doesnt dodge then it will attack normally
          int fA = fighterAttack(f1);
        } // 1st else
        if (user.h < 0) {// checks to see if health is less than 0 so when the health of either the user or the fighter is less then 0, it auto changes to 0 because you cant have negitive health
          user.h = 0;
        }
        if (dodge == false) {
          attackDefenseReduction = f1.a - user.d;// tracker to see how much damage is being done after defense reduction and if the number is a negitive number, it reverts up to 0
          if (attackDefenseReduction < 0) {
            attackDefenseReduction = 0;
          }
          System.out.println(f1.t + " attacked. " + f1.t + " did " + attackDefenseReduction + " damage." + ANSI_GREEN + " You are now at " + user.h + " health" + ANSI_RESET);
          System.out.println("");
          time();
          attackDefenseReduction = 0;
          damageCounter++;
        }
        if (f1.h <= 0 || user.h <= 0) {// checks to see if either the fighter or the user is at 0 health so once one player is, it will break out of the loop
          win = true;
          break;
        }
        if (move == 1) {
          boolean dodge4 = checkIfDodge(dodge);// goes to dodge method to see if the user or the fighter dodges the attack
          dodge = dodge4;// sets dodge to either true or false
          if (dodge == true) {// if dodge is true then it goes to the next turn
            System.out.println(f1.t + " dodged the attack");
            System.out.println("");
            time();
          } else {// if the user or the fighter doesnt dodge then it will attack normally
            int uA = userAttack(f1);
          } // 1st else
          if (f1.h < 0) {// checks to see if health is less than 0 so when the health of either the user or the fighter is less then 0, it auto changes to 0 because you cant have negitive health
            f1.h = 0;
          }
          if (dodge == false) {
            attackDefenseReduction = user.a - f1.d;// tracker to see how much damage is being done after defense reduction and if the number is a negitive number, it reverts up to 0
            if (attackDefenseReduction < 0) {
              attackDefenseReduction = 0;
            }
            System.out.println("You attacked. You did " + attackDefenseReduction + " damage. " + ANSI_GREEN + f1.t + " is now at " + f1.h + " health" + ANSI_RESET);
            System.out.println("");
            time();
            attackDefenseReduction = 0;
          }
          if (f1.h <= 0 || user.h <= 0) {// checks to see if either the fighter or the user is at 0 health so once one player is, it will break out of the loop
            win = true;
            break;
          }
        }
        if (move == 2) {
          user.a = user.a + 50;// boosts attack stat by 50 points
          attackBoostCounter++;
          System.out.println(ANSI_RED + "You did an attack boost. Your attack stat is now at " + user.a + " points" + ANSI_RESET);
          System.out.println("");
          time();
        }
      }
      if (f1.h <= 0 || user.h <= 0) {// checks to see if either the fighter or the user is at 0 health so once one player is, it will break out of the loop
        win = true;
        break;
      }
    } // end of while loop
    if (user.h <= 0) {// loser message
      System.out.println(ANSI_RED + "You lost. Good luck next time" + ANSI_RESET);
      System.out.println("");
      time();
      System.out.print("You will now return to the very beginning");
      System.out.println("");
      time();
      total = 0;// reverts static variables back to its original value
      total1 = 0;// reverts static variables back to its original value
      floor = 0;// reverts static variables back to its original value
      Welcome w = new Welcome();
      w.welcome();
      // return back to welcome
    }

    if (f1.h <= 0) {// winner message
      floor++;
      if (floor == 1 || floor == 3 || floor == 5 || floor == 7 || floor == 9 || floor == 11 || floor == 13) {// damage accumulator if statement so it holds the total damage done from the first enemy
        total = (f1.a - user.d) * damageCounter;
        if (total < 0) {
          total = 0;
        }
      }

      if (floor == 2 || floor == 4 || floor == 6 || floor == 8 || floor == 10 || floor == 12 || floor == 14) {// damage accumulator if statement so it holds the total damage done from the second enemy
        total1 = (f1.a - user.d) * damageCounter;
        if (total1 < 0) {
          total1 = 0;
        }
        user.h = user.h + total + total1; // at the end of the battle using an accumulator, the players health is restored based on the damage he or she took
        total = 0;// resets totals for next enemies for healing
        total1 = 0;
      }

      user.a = user.a - (50 * attackBoostCounter);// at the end of the battle using an accumulator, tracks the amount of time it used an attack bosting move so at the end of the battle , it restores the attack stat back to its base value

      if (floor == 14) {// resets static variables if the user chooses to play again after beating game
        total = 0;
        total1 = 0;
        floor = 0;
      }

      System.out.println(ANSI_GREEN + "Congrats on beating the enemy." + ANSI_RESET);
      System.out.println("");
      time();
      user.addExperience();
      time();
      user.checkLevelUp();
      System.out.println(ANSI_GREEN + "This is your new health after the battle: " + user.h + ANSI_RESET);
      time();
    }
  }// method
  /*
    checks to see if the user or enemy dodges an attack 
    Dillon, Bruce, Lukas
    ICS4U1 
    Jan 26 2021
  */

  public boolean checkIfDodge(boolean dodge) {
    Random r = new Random();// random number generator to pick number between 1-3 and sees if the user or the opponent dodges the attack
    int randomNum = r.nextInt(20);
    if (randomNum == 1 || randomNum == 2 || randomNum == 3) {
      dodge = true;// changes dodge to true
    } else {
      dodge = false; // changes dodge to false
    }
    return dodge;
  }// dodge

  /*
    User attacking enemy 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int userAttack(Character f1) {
    int attack = user.a - f1.d;// defense stat reduces damage taken
    if (attack < 0) {// if the defense stat makes the attack do negitive damage then we change the value of it to 0
      attack = 0;
    } else {
      f1.h = f1.h - attack;
      attack = 0;// resets attack for next turn
    } // 2nd else
    return f1.h;
  }// user attack

  /*
    Enemy attacks user 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public int fighterAttack(Character f1) {
    int attack = f1.a - user.d;// defense stat reduces damage taken
    if (attack < 0) {// if the defense stat makes the attack do negitive damage then we change the value of it to 0
      attack = 0;
    } else {
      user.h = user.h - attack;
      attack = 0;// resets attack for next turn
    } // 2nd else
    return user.h;
  }// fighter attack

  /*
    time to space out next display 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void time() {
    try {
      TimeUnit.SECONDS.sleep(1);
    } catch (InterruptedException e) {
    }
  }// time
}// main