import java.util.*;
import java.io.*;
import java.util.concurrent.TimeUnit;
/* 
  welcome screen
  Dillon, Bruce, Lukas
  ICS4U1
  Jan 26 2021
*/

class Welcome {
  // Declaring ANSI_RESET so that we can reset the color
  public static final String ANSI_RESET = "\u001B[0m";
  // Declaring the color
  // Custom declaration
  public static final String ANSI_YELLOW = "\u001B[33m";
  public static final String ANSI_RED = "\u001B[31m";
  public static final String ANSI_GREEN = "\u001B[32m";
  public static final String ANSI_BLUE = "\u001B[34m";
  public static final String ANSI_PURPLE = "\u001B[35m";

  static Scanner in = new Scanner(System.in);

  public void welcome() {
    int choice = 0;
    int choice1 = 0;
    boolean cont1 = false;
    boolean cont2 = false;
    boolean cont3 = true;

    while (cont3 == true) {
      File loading = new File("loading.txt");
      printLoadingScreen(loading);

      System.out.println("By; Bruce, Dillon, Lukas");
      System.out.println("");
      System.out.println(ANSI_YELLOW + "IF THERE ARE ERRORS IN THE WELCOME SCREEN, RESIZE THE WINDOW." + ANSI_RESET);
      System.out.println("");

      while (choice != 1 && choice != 3) {// while loop to make sure only enter 1 or 3
        while (cont1 == false) { // error proof to make sure the user can only enter a int number
          try {
            System.out.println(
                "IF YOU WANT TO START THE GAME PRESS 1. IF YOU WANT TO SEE THE INSTRUCTIONS PRESS 2. IF YOU WANT TO QUIT PRESS 3.");
            System.out.println("");
            choice = in.nextInt();
            System.out.println("");
            cont1 = true;
          } catch (Exception e) {// input a letter or a special character
            System.out.println(ANSI_YELLOW + "Invalid Input. Try again." + ANSI_RESET);
            System.out.println("");
            cont1 = false;
          }
          in.nextLine();
        } // while loop to check if user enters correct input: integer

        cont1 = false;
        if (choice == 1 || choice == 3) {
          break;
        } // if

        else {// input a number not 1 or 3
          if (choice == 2) {
            printInstructions();
          } // this will allow the user to see th instructions and then loop back to the beginning so they can either see the instructions again, quit or start the game

          else {
            System.out.println(ANSI_YELLOW + "Invalid Input. Try again" + ANSI_RESET);
            System.out.println("");
          } // else for any number that isnt 2
        } // else for input wrong number
      } // while

      if (choice == 3) {
        System.exit(0);
      }

      choice = 0;
      choice1 = 0;
      Test game = new Test();
      game.test();

      while (choice1 != 1 && choice1 != 2) {// while loop to make sure only enter 1
        while (cont2 == false) { // error proof to make sure the user can only enter a int number
          try {
            System.out.println("IF YOU WANT TO PLAY AGAIN PRESS 1 AND TO QUIT PRESS 2.");
            System.out.println("");
            choice1 = in.nextInt();
            System.out.println("");
            cont2 = true;
          } catch (Exception e) {
            System.out.println(ANSI_YELLOW + "Invalid Input. Try again." + ANSI_RESET);
            System.out.println("");
            cont2 = false;
          }
          in.nextLine();
        } // while loop to check if user enters correct input: integer
        cont2 = false;
        if (choice1 == 1 || choice1 == 2) {
          break;
        } else {
          System.out.println(ANSI_YELLOW + "Invalid Input. Try again" + ANSI_RESET);
          System.out.println("");
        }
      } // while
      if (choice1 == 1) {
        cont3 = true;
      } else if (choice1 == 2) {
        cont3 = false;
        System.exit(0);
      }
    } // while loop for replay game
  }// welcome

  /*
    Method to dely the time before the next test appears so the user has a chance to read it 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void time() {
    try {
      TimeUnit.MILLISECONDS.sleep(4200);
    } catch (InterruptedException e) {
    }
  }

  /*
    Method to dely the time before the next test appears so the user has a chance to read it 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void timeFast() {
    try {
      TimeUnit.MILLISECONDS.sleep(800);
    } catch (InterruptedException e) {
    }
  }

  /*
    Prints the instructions 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void printInstructions() {
    System.out.println("Before you start the game, this game includes a battle mechanic.");
    System.out.println("");
    time();
    System.out.println("Each character will have specific stats such as" + ANSI_GREEN + " health, " + ANSI_RESET+ ANSI_RED + "attack, " + ANSI_RESET + ANSI_BLUE + "defense " + ANSI_RESET + "and " + ANSI_PURPLE + "speed." + ANSI_RESET);
    System.out.println("");
    time();
    System.out.println("These stats will affect your battle experience.");
    System.out.println("");
    time();
    System.out.println(ANSI_GREEN + "The Health stat determines the amount of health both you and your enemy have." + ANSI_RESET);
    System.out.println("");
    time();
    System.out.println("The goal is to get the enemy's health down to 0 before they get your health down to 0.");
    System.out.println("");
    time();
    System.out.println(ANSI_RED + "The attack stat will detirmine the amount of damage both you and the enemy inflict on eachother."+ ANSI_RESET);
    System.out.println("");
    time();
    System.out.println("This next stat is very important...");
    System.out.println("");
    time();
    System.out.println(ANSI_BLUE+ "The defense stat helps in reducing the damage taken by attacks. BOTH the user and the enemy have this stat."+ ANSI_RESET);
    System.out.println("");
    time();
    System.out.println("For example, the user might have a base attack stat of 100 but the enemy has a defense stat of 40.");
    System.out.println("");
    time();
    System.out.println("Instead of the users attack doing 100 damage, it will only do 60 damage because of the reduction of the defense stat.");
    System.out.println("");
    time();
    System.out.println("This is applicable for the user as well.");
    System.out.println("");
    time();
    System.out.println(ANSI_PURPLE + "The final stat, the speed stat, will determine who goes first in battle." + ANSI_RESET);
    System.out.println("");
    time();
    System.out.println("Every fight you gain one experience point and it takes two points to level up.");
    System.out.println("");
    time();
    System.out.println(ANSI_GREEN + "In addition, each time you level up, your health gets fully restored." + ANSI_RESET);
    System.out.println("");
    time();
    System.out.println("With this in mind, make sure you pick your character carefully as there is no going back.");
    System.out.println("");
    time();
    System.out.println("One final thing. Once you lose even 1 battle, you lose forever and have to restart from the very beginning...");
    System.out.println("");
    time();
    System.out.println(ANSI_YELLOW + "With all of this in mind, enjoy and good luck!" + ANSI_RESET);
    System.out.println("");
    timeFast();
  }

  /*
    File reader
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void printLoadingScreen(File loading) {
    ArrayList<String> loadingScreens = new ArrayList<String>();
    try {
      // Initializes a new file object that will be read
      FileReader r = new FileReader(loading);
      BufferedReader readFile = new BufferedReader(r);
      String line;
      String loadingScreen;

      // Reads through all of the file
      while ((line = readFile.readLine()) != null) {
        loadingScreens.add(line);

      }
      // Traverses arraylist
      for (int i = 0; i < loadingScreens.size(); i++) {
        // Only prints the specific picture if it equals to the numPic variable

        loadingScreen = loadingScreens.get(i);
        // Only prints if the line isn't a #
        if (!(loadingScreens.get(i).equals("#"))) {
          System.out.println(loadingScreen);

        } else {
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");
          System.out.println("");

          timeFast();
        }
      }

      // Closes the file reader and buffered reader.
      readFile.close();
      r.close();
    }
    // Checks if file can be found
    catch (FileNotFoundException e) {
      System.out.println("File named " + loading + " not found. " + e);
    }
    // Checks if file can be properly read
    catch (IOException e) {
      System.out.println("IOException occured " + "while counting chars. " + e);
    }
  }// print enemy
}