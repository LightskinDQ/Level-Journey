import java.util.*;
import java.io.*;
import java.util.concurrent.TimeUnit;

/* 
Test
Dillon, Bruce, Lukas
ICS4U1
Jan 26 2021
*/
class Test {
  static Scanner in = new Scanner(System.in);
  static int numStory;
  static int numPic;
  // Declaring ANSI_RESET so that we can reset the color
  public static final String ANSI_RESET = "\u001B[0m";
  // Declaring the color
  // Custom declaration
  public static final String ANSI_YELLOW = "\u001B[33m";
  public static final String ANSI_RED = "\u001B[31m";
  public static final String ANSI_GREEN = "\u001B[32m";
  public static final String ANSI_BLUE = "\u001B[34m";
  public static final String ANSI_PURPLE = "\u001B[35m";
  public static final String ANSI_BLACK = "\u001B[30m";

  /*
    Code where the main storyline takes place 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void test() {
    numStory = 0;
    numPic = 0;

    String character = "";
    boolean valid = false;
    File story = new File("story.txt");
    File enemy = new File("enemy.txt");

    // Prints the first section of the story according to the story file
    printStory(story);
    // Adds delay before printing the next line
    fTime();
    while (valid == false) {
      System.out.println("What character do you want to choose:");
      System.out.println(ANSI_RED + "Attack" + ANSI_RESET);
      System.out.println(ANSI_BLUE + "Defense" + ANSI_RESET);
      System.out.println(ANSI_PURPLE + "Speed" + ANSI_RESET);
      character = in.next().toLowerCase();
      if (character.equalsIgnoreCase("attack") || character.equalsIgnoreCase("defense")
          || character.equalsIgnoreCase("speed")) {
        break;
      } // if
      else {
        System.out.println(ANSI_YELLOW + "Invalid Input. Try again" + ANSI_RESET);
      }
    } // loop to see if user put in proper word
    Character user = chooseCharacter(character);

    System.out.println("");
    // Creates a new battle object
    Battle battle = new Battle(user);
    int count = 0;
    while (count < 14) {
      // Prints the section of the story according to the story file
      printStory(story);
      // First enemy printed
      printEnemy(enemy);

      fTime();
      // Starts battle
      battle.start();
      fTime();
      System.out.println("");
      fTime();
      count++;
    }

    printStory(story);

  }// test

  /*
    Allows user to choose their special character 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan26 2021
  */
  public Character chooseCharacter(String choice) {
    Character user = null;
    String character = choice;
    if (character.equalsIgnoreCase("attack")) {// attack character choice
      System.out.println("");
      System.out.println(ANSI_RED + "You chose the attack type character" + ANSI_RESET);
      System.out.println("");
      Character attack = new Character(150, 120, 30, 90, "Attack", 0, 2, 1);

      user = attack;// makes the attack character characteristics the characteristics of the user
      nameCharacter(user);// names character
    }

    if (character.equalsIgnoreCase("defense")) {// defense character choice
      System.out.println("");
      System.out.println(ANSI_BLUE + "You chose the defense type character" + ANSI_RESET);
      System.out.println("");
      Character defense = new Character(150, 70, 55, 70, "Defense", 0, 2, 1);

      user = defense;// makes the defense character characteristics the chracteristics of the user
      nameCharacter(user);// names character
    }

    if (character.equalsIgnoreCase("speed")) {// speed character choice
      System.out.println("");
      System.out.println(ANSI_PURPLE + "You chose the speed type character" + ANSI_RESET);
      System.out.println("");
      Character speed = new Character(150, 80, 40, 100, "Speed", 0, 2, 1);
      user = speed;// makes the speed character characteristics the chracteristics of the user
      nameCharacter(user);// names character
    }
    return user;
  }

  /*
    names character user chooses 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void nameCharacter(Character user) {
    Scanner in = new Scanner(System.in);
    user.showStats();
    System.out.println("");
    System.out.print("What would you like to name your character: ");
    String name = in.nextLine();
  }// name character

  /*
    File reader to print off the storyline 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void printEnemy(File enemy) {
    try {
      // Initializes a new file object that will be read
      ArrayList<String> allPictures = new ArrayList<String>();

      FileReader r = new FileReader(enemy);
      BufferedReader readFile = new BufferedReader(r);
      String line;

      // Reads through all of the file
      while ((line = readFile.readLine()) != null) {
        // Adds all the lines to an arraylist
        allPictures.add(line);
      }
      int count = 0;
      String picture = null;
      // Traverses arraylist
      for (int i = 0; i < allPictures.size(); i++) {
        // Only prints the specific picture if it equals to the numPic variable
        if (count == numPic) {
          picture = allPictures.get(i);
          // Only prints if the line isn't a #
          if (!(allPictures.get(i).equals("#"))) {
            System.out.println(picture);
          }

        }
        // Everytime a # is read, a new picture is being checked and possibly will be printed
        if (allPictures.get(i).equals("#")) {
          count++;
        }

      }

      numPic++;

      // Closes the file reader and buffered reader.
      readFile.close();
      r.close();
    }
    // Checks if file can be found
    catch (FileNotFoundException e) {
      System.out.println("File named " + enemy + " not found. " + e);
    }
    // Checks if file can be properly read
    catch (IOException e) {
      System.out.println("IOException occured " + "while counting chars. " + e);
    }
  }// print enemy

  /*
    Prints file 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void printStory(File story) {

    try {
      // Initializes a new file object that will be read
      FileReader r = new FileReader(story);
      BufferedReader readFile = new BufferedReader(r);
      String line;
      ArrayList<String> allStory = new ArrayList<String>();
      // Reads through all of the file
      while ((line = readFile.readLine()) != null) {
        String[] words = line.split("#");
        // Runs through array and adds it to another array list
        for (int i = 0; i < words.length; i++) {
          allStory.add(words[i]);
        }
      }
      // The story is stored into a string value
      String output = (allStory.get(numStory));
      int x = output.length();
      // Looks through array and checks for every period to print a new line
      for (int i = 0; i < x; i++) {
        System.out.print(output.substring(i, i + 1));

        if ((output.substring(i, i + 1)).equals(".")) {
          int count = 0;
          // Checks if there are multiple periods so it doesn't print a new line
          while (output.substring(i + 1, i + 2).equals(".")) {

            i++;
            System.out.print(".");
            count++;
          }

          if (count == 0) {
            System.out.println("");
            System.out.println("");
          }
          time();
        }
      }
      System.out.println("");

      numStory++;
      // Closes the file reader and buffered reader.
      readFile.close();
      r.close();
    }
    // Checks if file can be found
    catch (FileNotFoundException e) {
      System.out.println("File named " + story + " not found. " + e);
    }
    // Checks if file can be properly read
    catch (IOException e) {
      System.out.println("IOException occured " + "while counting chars. " + e);
    }
  }// print story

  /*
    Method to dely the time before the next test appears so the user has a chance to read it 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */
  public void time() {
    try {
      TimeUnit.SECONDS.sleep(4);
    } catch (InterruptedException e) {
    }
  }// time
  /*
    Method to dely the time before the next test appears so the user has a chance to read it 
    Dillon, Bruce, Lukas 
    ICS4U1 
    Jan 26 2021
  */

  public void fTime() {
    try {
      TimeUnit.SECONDS.sleep(2);
    } catch (InterruptedException e) {
    }
  }// time
}// main